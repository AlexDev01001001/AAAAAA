<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b> <a href="#">ANC LOGISTICA INTEGRAL SAC</a></b>
    </div>
    <strong>Copyright &copy; 2020 Control de Asistencia</strong>
</footer>