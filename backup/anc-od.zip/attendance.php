<?php
include 'conn.php';
include 'timezone.php';
	function twopoints_on_earth($latitudeFrom, $longitudeFrom,
	$latitudeTo,  $longitudeTo)
	{
		$long1 = deg2rad($longitudeFrom);
		$long2 = deg2rad($longitudeTo);
		$lat1 = deg2rad($latitudeFrom);
		$lat2 = deg2rad($latitudeTo);

		//Haversine Formula
		$dlong = $long2 - $long1;
		$dlati = $lat2 - $lat1;

		$val = pow(sin($dlati/2),2)+cos($lat1)*cos($lat2)*pow(sin($dlong/2),2);

		$res = 2 * asin(sqrt($val));

		$radius = 3958.756;
		// *1.609344
		return ($res*$radius*1609.34);
		//return ($res * $radius);
	}

	$output = array('error'=>false);
	$gps = $_GET['gps'];
	$cbo_stores = "";
	if(isset($_GET['option'])==1){
		$global_gps = explode(",",$gps);
		$global_latitude = $global_gps[0];
		$global_longitude = $global_gps[1];
		$query_store="select t.id,t.description from (select t.*,(6371 * acos( cos( radians('$global_latitude') ) * cos( radians( t.latitude ) ) * cos( radians( t.longitude ) - radians('$global_longitude') )  + sin( radians('$global_latitude') ) * sin( radians( t.latitude ) )) ) * 1000 as distance  from (select a.id,a.description,SUBSTRING_INDEX(a.gps, ',', 1) as latitude, SUBSTRING_INDEX(a.gps, ',', -1) as longitude  from store a	) t ) t where t.distance <=500";
		$row_store= $conn->query($query_store);
		//$output = $row_store->fetch_all();
		$result_store = array();
		while($row = $row_store-> fetch_assoc()){
			$result_store[] = $row;
		}
		$output = $result_store;
		 
	}
	

	if(isset($_GET['employee'])){
		
		$cbo_stores=$_GET['cbostores'];
		

		$employee = $_GET['employee'];		
		$status = $_GET['status'];
		
		

		
		
		
		//$motivo=$_GET['motivo'];
		$sql = "SELECT * FROM employees WHERE employee_id = '$employee' and status in (1,2)";
		$query = $conn->query($sql);

		
		//date(date_add(date_add(UTC_TIMESTAMP(),interval -5 hour),interval -5 hour)) = gmdate('Y-m-d');
		//código de usuario reemplazo
		//$replace_employee=$_GET['replace_employee'];
		
		if($query->num_rows > 0){
			//$global_gps = explode(",",$row['gps']);
			//$global_latitude = $global_gps[0];
			//$global_longitude = $global_gps[1];

			

			//var_dump($gps_row);
			/*
			for($i=0;$i<$query->num_rows;$i++){

				$validate_distance = twopoints_on_earth($global_latitude,$global_longitude,$latitude,$longitude);
			}*/
			//var_dump($validate_distance);

			$row = $query->fetch_assoc();
			//var_dump($row);
			$id = $row['id'];			
			
			
			//$validate_distance = twopoints_on_earth($global_latitude,$global_longitude,$latitude,$longitude);

			//var_dump($validate_distance);
			/*
			if($validate_distance>300 & $status == 'in'){				
				$output['error']=true;
				$output['message']="Usted no se encuentra dentro del rango de la zona de marcación";
				echo json_encode($output);
				return;
			}
			*/
			if($status == 'in'){
				$search_attendance = "select a.id,b.firstname,b.lastname from attendance a left join employees b on a.employee_id=b.id where a.date=date(date_add(UTC_TIMESTAMP(),interval -5 hour)) and b.employee_id='$employee' and a.status='0' and a.idreplace='0' and a.time_out='00:00:00'";
				$exec_search_attendance = $conn->query($search_attendance);
				if($exec_search_attendance->num_rows == 0){				
					/*	
					//Buscar registro de reemplazo status in (6,7) para relacionarlo en idreplace					
					$search_idreplace  = "select a.id from attendance a left join employees b on a.employee_id=b.id where a.date=date(date_add(UTC_TIMESTAMP(),interval -5 hour)) and b.employee_id='$employee' and a.status in (6,7)";
					$result_idreplace = $conn->query($search_idreplace);
					$value_idreplace = 0;
					$search_idreplace_bool = false;
					if($result_idreplace->num_rows>0){
						$search_idreplace_bool=true;
						$row_idreplace = $result_idreplace -> fetch_assoc();
						$value_idreplace = $row_idreplace['id'];
					}					
					//
					// buscar registro status=0 , idreplace >0 para cancelar el campo $value_idreplace
					
					$search_attendance_affect = "select a.id from attendance a left join employees b on a.employee_id=b.id where a.date=date(date_add(UTC_TIMESTAMP(),interval -5 hour)) and b.employee_id='$employee' and a.status='0' and idreplace>0";
					$result_attendance_affect = $conn->query($search_attendance_affect);
					if($result_attendance_affect->num_rows>0){

						$update_search_employees_replace = "update employees_replace set status=1 where replace_date=date(date_add(UTC_TIMESTAMP(),interval -5 hour)) and replace_employee_id='$employee'";
						$exec_update_search_employees_replace = $conn->query($update_search_employees_replace);	
						
						$value_idreplace='0';
					}*/
					//
					$logstatus=0;
					$insert_attendance = "INSERT INTO attendance (employee_id, date, time_in, status,gps,motivo,idreplace,store) VALUES ('$id', date(date_add(UTC_TIMESTAMP(),interval -5 hour)), date_add(UTC_TIMESTAMP(),interval -5 hour), '$logstatus','$gps','','','$cbo_stores')";
					$exec_insert_attendance = $conn->query($insert_attendance);
					$output['error']=false;
					$output['message']="Entrada : ". $row['firstname'] .' ' . $row['lastname'];
				/*$search_ina = "select a.id,b.firstname,b.lastname from attendance a left join employees b on a.employee_id=b.id where a.date=date(date_add(UTC_TIMESTAMP(),interval -5 hour)) and b.employee_id='$employee' and a.status in (4,5)";
				$exec_search_ina = $conn->query($search_ina);
				if($exec_search_ina->num_rows > 0){
					$output['error']=true;
					$output['message']='Usted ha informado de su inasistencia, no puedo marcar su entrada';
				}else{
					
					}else{
						/*
						$search_employees_replace = "select * from employees_replace where replace_date=date(date_add(UTC_TIMESTAMP(),interval -5 hour)) and replace_employee_id='$employee' and status='0'";
						$exec_search_employes_replace = $conn->query($search_employees_replace);				
						if($exec_search_employes_replace->num_rows>0){
							$update_search_employees_replace = "update employees_replace set status=1 where replace_date=date(date_add(UTC_TIMESTAMP(),interval -5 hour)) and replace_employee_id='$employee'";
							$exec_update_search_employees_replace = $conn->query($update_search_employees_replace);							
							$logstatus=0;
							$insert_attendance = "INSERT INTO attendance (employee_id, date, time_in, status,gps,motivo) VALUES ('$id', date(date_add(UTC_TIMESTAMP(),interval -5 hour)), date_add(UTC_TIMESTAMP(),interval -5 hour), '$logstatus','$gps','')";
							$exec_insert_attendance = $conn->query($insert_attendance);
							$output['error']=false;
							$output['message']="Entrada : ". $row['firstname'] .' ' . $row['lastname'];
							//$output['error']=false;
							//$output['message']="existe relación";
						}else{
							$output['error']=true;
							$output['message']='Has registrado tu entrada por hoy';
						}
						
					}*/
				}else{
					$output['error']=true;
					$output['message']='Debes marcar tu salida';
				}
			}
			else if ($status == 'out') {
				
				$sql = "SELECT *, attendance.id AS uid FROM attendance LEFT JOIN employees ON employees.id=attendance.employee_id WHERE attendance.employee_id = '$id' AND time_in IS NOT NULL and (hour(time_out)=0 and minute(time_out)=0 and second(time_out)=0) and attendance.status not in (4,5,6,7)  order by attendance.id desc LIMIT 1";
				$query = $conn->query($sql);
				if($query->num_rows < 1){
					$output['error'] = true;
					$output['message'] = 'No se puede registrar tu salida, sin previamente registrar tu entrada.';
				}
				else{
					$row = $query->fetch_assoc();
					if($row['time_out'] != '00:00:00'){
						$output['error'] = true;
						$output['message'] = 'Has registrado tu salida satisfactoriamente por el día de hoy';
					}
					else{
						
						$sql = "UPDATE attendance SET time_out = date_add(UTC_TIMESTAMP(),interval -5 hour) WHERE id = '".$row['uid']."'";
						if($conn->query($sql)){
							$output['message'] = 'Salida: '.$row['firstname'].' '.$row['lastname'];

							$sql = "SELECT * FROM attendance WHERE id = '".$row['uid']."'";
							$query = $conn->query($sql);
							$urow = $query->fetch_assoc();

							$time_in = $urow['time_in'];
							$time_out = $urow['time_out'];

							$sql = "SELECT * FROM employees LEFT JOIN schedules ON schedules.id=employees.schedule_id WHERE employees.id = '$id'";
							$query = $conn->query($sql);
							$srow = $query->fetch_assoc();

							if($srow['time_in'] > $urow['time_in']){
								$time_in = $srow['time_in'];
							}

							if($srow['time_out'] < $urow['time_in']){
								$time_out = $srow['time_out'];
							}

							$time_in = new DateTime($time_in);
							$time_out = new DateTime($time_out);
							$interval = $time_in->diff($time_out);
							$hrs = $interval->format('%h');
							$mins = $interval->format('%i');
							$mins = $mins/60;
							$int = $hrs + $mins;
							if($int > 4){
								$int = $int - 1;
							}

							$sql = "UPDATE attendance SET num_hr = '$int' WHERE id = '".$row['uid']."'";
							$conn->query($sql);
						}
						else{
							$output['error'] = true;
							$output['message'] = $conn->error;
						}
					}
					
				}
			}else if($status == "replace"){
				/*
				if($conn->query($sql)){					
					$output['message'] = 'Entrada de reemplazo : '.$row['firstname'].' '.$row['lastname'];	
						
				}else{
					$output['error'] = true;
					$output['message'] = "El reemplazo ya fue asignado por el día de hoy";
				}
				*/
			}else{
				/*
				$Fquery = "select a.*,b.employee_id from attendance a left join employees b on a.employee_id=b.id where b.employee_id='$employee' and a.date=date(date_add(UTC_TIMESTAMP(),interval -5 hour))";
				$Fresult = $conn->query($Fquery);
				if($Fresult->num_rows < 1){
					$sched = $row['schedule_id'];
					$lognow = date('H:i:s');
					$sql = "SELECT * FROM schedules WHERE id = '$sched'";
					$squery = $conn->query($sql);
					$srow = $squery->fetch_assoc();
					$logstatus = 4;
					//
					$sql = "INSERT INTO attendance (employee_id, date, time_in, status,gps,motivo) VALUES ('$id', date(date_add(UTC_TIMESTAMP(),interval -5 hour)), date_add(UTC_TIMESTAMP(),interval -5 hour), '$logstatus','$gps','$motivo')";
					if($conn->query($sql)){
						
						$output['message'] = 'Se informará de tu inasistencia  '.$row['firstname'].' '.$row['lastname'];
					}
					else{
						$output['error'] = true;
						$output['message'] = $conn->error;
					}
				}else{					
					$output['error'] = true;
					$output['message'] = 'No puedes marcar tu inasistencia, porque tienes un registro de entrada';
				}
				*/
			}
		}
		else{
			$output['error'] = true;
			$output['message'] = 'ID de empleado no encontrado';
		}
		
	}

	echo json_encode($output);

?>