<?php include 'header.php'; ?>
<script>
    $.ajax({
        
    })
</script>