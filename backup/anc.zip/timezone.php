<?php
	$timezone = 'America/Lima';
	date_default_timezone_set($timezone);
?>